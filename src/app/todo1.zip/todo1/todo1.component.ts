import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-todo1',
  templateUrl: './todo1.component.html',
  styleUrls: ['./todo1.component.css']
})
export class Todo1Component implements OnInit {

  todos = [
    {id: 1, taskName: "Hello 1", isCompleted: false},
    {id: 2, taskName: "Hello 2", isCompleted: true}
  ];

  title = '';
  expanded = true;
  classAdd = false;
  isCompleted = false;


  constructor() { }

  ngOnInit() {
    console.log(this.todos);
  }

  onClick(){
    console.log("New Added -- ", this.title);
    this.todos.push({id: this.todos.length+1,taskName: this.title, isCompleted: false});
    this.title = '';

  }
  onDelete(i){
    console.log(this.todos.indexOf(i));
    //const index = this.todos.indexOf(i);
    //this.todos.splice(index, 1);
  }

  toggleTable(){
    console.log("Hide Show");
    this.expanded = !this.expanded;
    this.classAdd = !this.classAdd;
  }

  completedTask(){
    // Add toggle Class name {taskDone} When click on checkbox True / False;
  }

}
